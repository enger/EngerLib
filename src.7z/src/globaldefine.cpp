//#include "stdafx.h"
#include <globaldeclear.h>
#include <boost/thread/mutex.hpp>
#include <string>
#include <strstream>
#include <vector>
#include <boost/algorithm/string.hpp>
#include <boost/filesystem/path.hpp>
#include <boost/filesystem/operations.hpp>
#include <boost/format.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>  
#include <Windows.h>
using namespace std;

/******************************************************************************
���ܣ�stringת��Ϊwstring
������1.str Ҫת����string����
����ֵ��ת�����wstring����
ʱ�䣺2011.10.8
���ߣ�EngerWu
********************************************************************************/
wstring MultCharToWideChar(const string& str)
{
	//��ȡ�������Ĵ�С��������ռ䣬��������С�ǰ��ַ������
	int len=MultiByteToWideChar(CP_ACP,0,str.c_str(),(int)str.size(),NULL,0);
	TCHAR *buffer=new TCHAR[len+1];
	//���ֽڱ���ת���ɿ��ֽڱ���
	MultiByteToWideChar(CP_ACP,0,str.c_str(),(int)str.size(),buffer,len);
	buffer[len]='\0';//�����ַ�����β
	//ɾ��������������ֵ
	wstring return_value;
	return_value.append(buffer);
	delete []buffer;
	buffer=0;
	return return_value;
}

/******************************************************************************
���ܣ�wstringת��Ϊstring
������1.str Ҫת����wstring����
����ֵ��ת�����string����
ʱ�䣺2011.10.8
���ߣ�EngerWu
********************************************************************************/
string WideCharToMultiChar(const wstring& str)
{
	string return_value;
	//��ȡ�������Ĵ�С��������ռ䣬��������С�ǰ��ֽڼ����
	int len=WideCharToMultiByte(CP_ACP,0,str.c_str(),(int)str.size(),NULL,0,NULL,NULL);
	char *buffer=new char[len+1];
	WideCharToMultiByte(CP_ACP,0,str.c_str(),(int)str.size(),buffer,len,NULL,NULL);
	buffer[len]='\0';
	//ɾ��������������ֵ
	return_value.append(buffer);
	delete []buffer;
	buffer=0;
	return return_value;
}

bool IsDirectoryExists( const string & path)
{
	int nRes = 0;
	namespace fs = boost::filesystem3;
	fs::path full_path= fs::system_complete( fs::path(path, fs::native ) );
	return fs::exists(full_path);
}
bool CreatePath(const string& path)
{
	namespace fs = boost::filesystem;
	fs::path full_path( fs::initial_path() );
	full_path = fs::system_complete( fs::path(path, fs::native ) );
	//�жϸ�����Ŀ¼�Ƿ���ڣ�����������Ҫ����
	if ( !fs::exists( full_path ) )
	{
		// ���������Ŀ¼
		bool bRet = fs::create_directories(full_path);
		if (false == bRet)
		{
			return false;
		}

	}
	return true;
}
void WriteLog(const string & strlog)
{
	string strpath=GetModelBasePath()+"\\log";
	if (!IsDirectoryExists(strpath))
	{
		CreatePath(strpath);
	}

	std::string strTime = boost::posix_time::to_iso_string(boost::posix_time::second_clock::local_time());  
	strpath+="\\"+strTime.substr(0,8)+".log";
	ofstream ofs(strpath,ios::app);
	ofs<<strTime<<"	";
	ofs<<strlog<<"\n";
	ofs.close();
}
string GetFormateDataSize(unsigned long long ullsize)
 {
	 stringstream strstrm;
	 if (ullsize<KB)
	 {
		 strstrm<<ullsize<<" B";
	 }
	 else if (ullsize<MB)
	 {
		 strstrm<<(double)ullsize/KB<<" KB";
	 }
	 else if (ullsize<GB)
	 {
		 strstrm<<(double)ullsize/MB<<" MB";
	 }
	 else if (ullsize<TB)
	 {
		  strstrm<<(double)ullsize/GB<<" GB";
	 }
	 else
	 {
		 strstrm<<(double)ullsize/TB<<" TB";
	 }
	 return strstrm.str();
 }
string GetModelBasePath()
{
	char fullname[MAX_PATH]={0};
	GetModuleFileNameA(NULL,fullname,sizeof(fullname));
	for (int i=MAX_PATH-1;i>0;i--)
	{
		if (fullname[i]==L'\\')
		{
			fullname[i]=L'\0';
			break;
		}
	}
	return string(fullname);
}
string GetModelName()
{
	CHAR fullname[MAX_PATH]={0};
	GetModuleFileNameA(NULL,fullname,sizeof(fullname));
	string sztemp(fullname);
	int index1 = sztemp.find_last_of(L'\\');
	int index2 = sztemp.find_last_of(L'.');
	return sztemp.substr(index1+1,index2-index1-1);
}
string GetErrorDetails(DWORD dwErrorCode)
{
	// Get the error code
	string szErrorDetails;
	DWORD dwError = dwErrorCode;//GetDlgItemInt(hwnd, IDC_ERRORCODE, NULL, FALSE);

	HLOCAL hlocal = NULL;   // Buffer that gets the error message string

	// Use the default system locale since we look for Windows messages.
	// Note: this MAKELANGID combination has 0 as value
	DWORD systemLocale = MAKELANGID(LANG_NEUTRAL, SUBLANG_NEUTRAL);

	//// Get the error code's textual description
	BOOL fOk = FormatMessageA(
		FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS |
		FORMAT_MESSAGE_ALLOCATE_BUFFER, 
		NULL, dwError, systemLocale, 
		(PSTR) &hlocal, 0, NULL);

	if (!fOk)
	{
		// Is it a network-related error?
		HMODULE hDll = LoadLibraryExA(("netmsg.dll"), NULL, 
			DONT_RESOLVE_DLL_REFERENCES);

		if (hDll != NULL)
		{
			fOk = FormatMessageA(
				FORMAT_MESSAGE_FROM_HMODULE | FORMAT_MESSAGE_IGNORE_INSERTS |
				FORMAT_MESSAGE_ALLOCATE_BUFFER,
				hDll, dwError, systemLocale,
				(PSTR) &hlocal, 0, NULL);
			FreeLibrary(hDll);
		}
	}

	if (fOk && (hlocal != NULL)) 
	{
		szErrorDetails = ((PCSTR) LocalLock(hlocal));
		LocalFree(hlocal);
	} 
	else
	{
		szErrorDetails=("û���ҵ���������Ϣ");
	}
	return szErrorDetails;
}