#include "datarancer.h"
#include "globaldeclear.h"
#include "BufferObj.h"
//#include "ChongQingData.h"
CDataTrancer::CDataTrancer(void)
{
	m_bStop=false;
	send_pool_prt = std::shared_ptr<boost::threadpool::pool>(new boost::threadpool::pool(1));
}


CDataTrancer::~CDataTrancer(void)
{
}
//int CDataTrancer::Initiate()
//{
//	int ret=-1;
//	//CString szPath=GetModelBasePath()+TEXT("\\config.ini");
//	//CStdioFile RFile;
//	//try
//	//{
//	//	//if (!PathFileExists(szPath))
//	//	//{
//	//	//	return -1;
//	//	//}
//	//	//RFile.Open(szPath,CFile::typeText ); 
//	//	//CString szReadLine;
//	//	////���ն˿�
//	//	//if (RFile.ReadString(szReadLine))
//	//	//{
//	//	//	//m_usRecivePort=_tstoi(szReadLine.GetBuffer());
//	//	//	//szReadLine.ReleaseBuffer();
//	//	//}
//	//	//else
//	//	//{
//	//	//	return -1;
//	//	//}
//	//	////���Ͷ˿�
//	//	//if (RFile.ReadString(szReadLine))
//	//	//{
//	//	//	m_usSendPort=_tstoi(szReadLine.GetBuffer());
//	//	//	szReadLine.ReleaseBuffer();
//	//	//}
//	//	//else
//	//	//{
//	//	//	return -1;
//	//	//}
//	//	////���б�ʶ
//	//	//if (RFile.ReadString(szReadLine))
//	//	//{
//	//	//	//m_strCityFlag=WideCharToMultiChar(wstring(szReadLine.GetBuffer()));
//	//	//	//szReadLine.ReleaseBuffer();
//	//	//}
//	//	//else
//	//	//{
//	//	//	return -1;
//	//	//}
//	//	//ret=0;
//	//}
//	//catch (CException* e)
//	//{
//	//	//if (RFile.m_hFile!=CFile::hFileNull)
//	//	//{
//	//	//	RFile.Close();
//	//	//}
//	//	//TCHAR szError[MAX_PATH];
//	//	//e->GetErrorMessage(szError,MAX_PATH-1);
//	//	//string strError=WideCharToMultiChar(wstring(szError));
//	//	//CStringA szLogText;
//	//	//szLogText.Format(("# ERR: CException in %s(%s) on line %d \r\n \
//	//	//				  # ERR:%s"),
//	//	//				  __FILE__,__FUNCTION__,__LINE__,
//	//	//				  strError.c_str());
//	//	//WriteLog(CString(MultCharToWideChar(string(szLogText.GetBuffer())).c_str()));
//
//	//}
//	return ret;
//}

int CDataTrancer::Start()
{
	int ret=0;
	//m_SocketSeverUDP.SetPort(m_usRecivePort);
	//m_SocketServer.SetServerPort(m_usSendPort);
	m_sktClientTCP.SetAddrs(m_strServerAdd);
	m_sktClientTCP.SetPorts(m_usPort);

	//if ((ret=m_sktClientTCP.Start())!=0)
	//{
	//	return ret;
	//}
	//if ((ret=m_SocketSeverUDP.Start())!=0)
	//{
	//	m_SocketServer.Stop();
	//	return ret;
	//}
	m_bStop=false;
	//send_pool_prt->schedule(boost::bind(&CDataTrancer::SendData,this));
	return ret;
}
void CDataTrancer::Stop()
{
	m_bStop=true;
	//m_SocketSeverUDP.Stop();
	//m_SocketServer.Stop();

	m_sktClientTCP.Stop();
	send_pool_prt->clear();
	send_pool_prt->wait();
}
void CDataTrancer::SendData(const std::shared_ptr<CBufferObj>& ptr_buffer)
{
	//m_sktClientTCP.SendData(ptr_buffer);
//	vector<std::shared_ptr<CBufferObj>> vecBuffer;
//	vecBuffer.reserve(100);
//	std::shared_ptr<char> ptr_buffer;
//	int bufferlen=0;
//	while(!m_bStop)
//	{
//		m_SocketSeverUDP.GetDataBuffer(vecBuffer);
//
//		if (vecBuffer.size()==0)
//		{
//			Sleep(50);
//			continue;
//		}
//#if 1
//		//���㻺������С
//		int len=0;
//		for (size_t i=0;i<vecBuffer.size();i++)
//		{
//			len+=vecBuffer[i]->len_buffer;
//		}
//		if (len==0)
//		{
//			continue;
//		}
//		//��仺����
//		ptr_buffer = std::shared_ptr<char>(new char[len]);
//		int offset=0;
//		for (size_t i=0;i<vecBuffer.size();i++)
//		{
//			memcpy_s(&(*ptr_buffer)+offset,len-offset,&(*vecBuffer[i]->ptr_buffer),vecBuffer[i]->len_buffer);
//			offset+=vecBuffer[i]->len_buffer;
//		}
//
//		//m_SocketServer.SendMsg(ptr_buffer,len);
//
//		//��������
//#endif
//#if 0
//		//���㻺������С
//		int len=0;
//		for (size_t i=0;i<vecBuffer.size();i++)
//		{
//			len+=vecBuffer[i]->len_buffer;
//		}
//		//��仺����
//		if (ptr_buffer==0 || bufferlen==0)
//		{
//			ptr_buffer = std::shared_ptr<char>(new char[len]);
//			int offset=0;
//			for (size_t i=0;i<vecBuffer.size();i++)
//			{
//				memcpy_s(&(*ptr_buffer)+offset,len-offset,&(*vecBuffer[i]->ptr_buffer),vecBuffer[i]->len_buffer);
//				offset+=vecBuffer[i]->len_buffer;
//			}
//			bufferlen=len;
//		}
//		else
//		{
//			//CString sztemp;
//			//sztemp.Format(TEXT("%s ��������С=%d"),MultCharToWideChar(m_sName).c_str(),bufferlen);
//			//WriteLog(sztemp);
//			//����ԭ�л�����
//			std::shared_ptr<char> ptr_temp_buffer=std::shared_ptr<char>(new char[bufferlen]);
//			memcpy_s(&(*ptr_temp_buffer),bufferlen,&(*ptr_buffer),bufferlen);
//			//�����µĴ�С
//			int newbufferlen=len+bufferlen;
//			//�����µĻ�����
//			ptr_buffer = std::shared_ptr<char>(new char[newbufferlen]);
//			int offset=0;
//			//
//			memcpy_s(&(*ptr_buffer),newbufferlen,&(*ptr_temp_buffer),bufferlen);
//			offset=bufferlen;
//			//��仺����
//			for (size_t i=0;i<vecBuffer.size();i++)
//			{
//				memcpy_s(&(*ptr_buffer)+offset,newbufferlen-offset,&(*vecBuffer[i]->ptr_buffer),vecBuffer[i]->len_buffer);
//				offset+=vecBuffer[i]->len_buffer;
//			}
//			//���óɻ�������С
//			bufferlen=newbufferlen;
//		}
//		//�ҽ�β
//		int idx=bufferlen-1;
//		char* pbuffer = &(*ptr_buffer);
//		for (;idx>=0;idx--)
//		{
//			if (pbuffer[idx]=='\n')
//			{
//				break;
//			}
//		}
//		//�ҵ���β
//		if (idx>0)
//		{
//			//����ʣ���ֽ�
//			int backuplen=bufferlen-idx-1;
//			std::shared_ptr<char> ptr_backup_buffe=0;
//			if (backuplen>0)
//			{
//				ptr_backup_buffe=std::shared_ptr<char>(new char[backuplen]);
//				memcpy_s(&(*ptr_backup_buffe),backuplen,&(*ptr_buffer)+idx+1,backuplen);
//			}
//
//			vector<std::shared_ptr<CChongQingData>> vecGPSData;
//			(&(*ptr_buffer))[idx]='\0';
//			if (CChongQingData::MakeCars(ptr_buffer,vecGPSData,m_strCityFlag)>0)
//			{
//				string strData="";
//				for (size_t i=0;i<vecGPSData.size();i++)
//				{
//					strData.append(vecGPSData[i]->ToString()).append("\r\n");
//				}
//				if (strData.length()>0)
//				{
//					std::shared_ptr<char> bufferSend = std::shared_ptr<char>(new char[strData.length()]);
//					memset(&(*bufferSend),0,strData.length());
//					memcpy_s(&(*bufferSend),strData.length(),strData.c_str(),strData.length());
//					m_SocketServer.SendMsg(bufferSend,strData.length());
//				}
//			}
//		
//			if ((backuplen>0))
//			{
//				ptr_buffer = std::shared_ptr<char>(new char[backuplen]);
//				memcpy_s(&(*ptr_buffer),backuplen,&(*ptr_backup_buffe),backuplen);
//			}
//			bufferlen=backuplen;
//		}
//
//#endif
//		vecBuffer.clear();
//	}
//	//CString sztemp;
//	//sztemp.Format(TEXT("���ݴ����߳��˳���\r\n"));
//	//WriteLog(sztemp);

}
//void CReciveAndTrans::SetSaveData(bool bSave)
//{
//	//m_SocketClient.SaveFile(bSave);
//}
//void CReciveAndTrans::SetTransData(bool bTrans)
//{
//	m_SocketServer.TransData(bTrans);
//}