#include "State.h"


CState::CState(void)
	:ull_rev_size(0)
	,ull_snd_size(0)
{
}


CState::~CState(void)
{
}
