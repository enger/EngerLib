#include "..\include\DataParser.h"


CDataParser::CDataParser(void)
{
}


CDataParser::~CDataParser(void)
{
}
