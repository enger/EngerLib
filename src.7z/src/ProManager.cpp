#include "ProManager.h"
#include <globaldeclear.h>
#include <strstream>
#include <sstream>

CProManager::CProManager(void)
{
}


CProManager::~CProManager(void)
{
}

void CProManager::AddPro(const string& dllpath,bool startNow)
{
	try
	{
		std::shared_ptr<CProInfo> prt_pro = std::shared_ptr<CProInfo>(new CProInfo(dllpath));
		int idx1 = dllpath.find_last_of('\\');
		int idx2 = dllpath.find_last_of('/');
		string dllname;
		if (idx1>=0)
		{
			dllname=dllpath.substr(idx1+1,dllpath.length()-idx1-1);
		}
		else if(idx2>=0)
		{
			dllname=dllpath.substr(idx2+1,dllpath.length()-idx2-1);
		}
		else
		{
			dllname=dllpath;
		}
		//string sernum=prt_pro->GetSerNum();
		if (dllname.length()>0)
		{
			map<string,shared_ptr<CProInfo>>::iterator ite=_mapPro.find(prt_pro->GetSerNum());
			if (ite==_mapPro.end())
			{
				_mapPro.insert(make_pair(prt_pro->GetSerNum(),prt_pro));
				if (startNow)
				{
					prt_pro->Start();
				}
			}
		}
	}
	catch (std::exception& e)
	{
		std::stringstream strss;
		strss<<"# ERR: std::exception in "<<__FILE__<<"("<<__FUNCTION__<<")"
			<<" on line "<<__LINE__<<"\n";
		strss<<"# ERR:"<<e.what();
		WriteLog(strss.str());
	}

}
void CProManager::RemovePro(const string& sernum)
{
	try
	{
		map<string,shared_ptr<CProInfo>>::iterator ite = _mapPro.find(sernum);
		if (ite!=_mapPro.end())
		{
			ite->second->Stop();
			ite=_mapPro.erase(ite);
		}
	}
	catch (std::exception& e)
	{
		std::stringstream strss;
		strss<<"# ERR: std::exception in "<<__FILE__<<"("<<__FUNCTION__<<")"
			<<" on line "<<__LINE__<<"\n";
		strss<<"# ERR:"<<e.what();
		WriteLog(strss.str());
	}
}
void CProManager::ClearPro()
{
	try
	{
		Stop();
		_mapPro.clear();
	}
	catch (std::exception& e)
	{
		std::stringstream strss;
		strss<<"# ERR: std::exception in "<<__FILE__<<"("<<__FUNCTION__<<")"
			<<" on line "<<__LINE__<<"\n";
		strss<<"# ERR:"<<e.what();
		WriteLog(strss.str());
	}

}
void CProManager::Start()
{
	try
	{
		map<string,shared_ptr<CProInfo>>::iterator ite = _mapPro.begin();
		for (;ite!=_mapPro.end();ite++)
		{
			ite->second->Start();
		}
	}
	catch (std::exception& e)
	{
		std::stringstream strss;
		strss<<"# ERR: std::exception in "<<__FILE__<<"("<<__FUNCTION__<<")"
			<<" on line "<<__LINE__<<"\n";
		strss<<"# ERR:"<<e.what();
		WriteLog(strss.str());
	}
}
void CProManager::Start(const string& sernum)
{
	try
	{
		map<string,shared_ptr<CProInfo>>::iterator ite = _mapPro.find(sernum);
		if (ite!=_mapPro.end())
		{
			ite->second->Start();
		}
	}
	catch (std::exception& e)
	{
		std::stringstream strss;
		strss<<"# ERR: std::exception in "<<__FILE__<<"("<<__FUNCTION__<<")"
			<<" on line "<<__LINE__<<"\n";
		strss<<"# ERR:"<<e.what();
		WriteLog(strss.str());
	}

}
void CProManager::Stop()
{
	try
	{
		map<string,shared_ptr<CProInfo>>::iterator ite = _mapPro.begin();
		for (;ite!=_mapPro.end();ite++)
		{
			ite->second->Stop();
		}
	}
	catch (std::exception& e)
	{
		std::stringstream strss;
		strss<<"# ERR: std::exception in "<<__FILE__<<"("<<__FUNCTION__<<")"
			<<" on line "<<__LINE__<<"\n";
		strss<<"# ERR:"<<e.what();
		WriteLog(strss.str());
	}

}
void CProManager::Stop(const string& sernum)
{
	try
	{
		map<string,shared_ptr<CProInfo>>::iterator ite = _mapPro.find(sernum);
		if (ite!=_mapPro.end())
		{
			ite->second->Stop();
		}
	}
	catch (std::exception& e)
	{
		std::stringstream strss;
		strss<<"# ERR: std::exception in "<<__FILE__<<"("<<__FUNCTION__<<")"
			<<" on line "<<__LINE__<<"\n";
		strss<<"# ERR:"<<e.what();
		WriteLog(strss.str());
	}

}
void CProManager::Update()
{
	try
	{
		map<string,shared_ptr<CProInfo>>::iterator ite = _mapPro.begin();
		for (;ite!=_mapPro.end();ite++)
		{
			ite->second->Update();
		}
	}
	catch (std::exception& e)
	{
		std::stringstream strss;
		strss<<"# ERR: std::exception in "<<__FILE__<<"("<<__FUNCTION__<<")"
			<<" on line "<<__LINE__<<"\n";
		strss<<"# ERR:"<<e.what();
		WriteLog(strss.str());
	}

}
void CProManager::Update(const string& dllname)
{
	try
	{
		map<string,shared_ptr<CProInfo>>::iterator ite = _mapPro.find(dllname);
		if (ite!=_mapPro.end())
		{
			ite->second->Update();
		}
	}
	catch (std::exception& e)
	{
		std::stringstream strss;
		strss<<"# ERR: std::exception in "<<__FILE__<<"("<<__FUNCTION__<<")"
			<<" on line "<<__LINE__<<"\n";
		strss<<"# ERR:"<<e.what();
		WriteLog(strss.str());
	}

}

shared_ptr<CProInfo> CProManager::GetProInfo(string dllname)
{
	try
	{
		map<string,shared_ptr<CProInfo>>::const_iterator ite = _mapPro.find(dllname);
		if (ite!=_mapPro.end())
		{
			return ite->second;
		}
	}
	catch (std::exception& e)
	{
		std::stringstream strss;
		strss<<"# ERR: std::exception in "<<__FILE__<<"("<<__FUNCTION__<<")"
			<<" on line "<<__LINE__<<"\n";
		strss<<"# ERR:"<<e.what();
		WriteLog(strss.str());
	}

	return nullptr;
}
