#include "MyProInfo.h"
#include <iostream>
#include <vector>
#include <boost/algorithm/string.hpp>
#include <boost/lexical_cast.hpp>
#include <globaldeclear.h>
CProInfo::CProInfo(string dllPath)
	:_start(0)
	,_stop(0)
	,_update(0)
	,_getserver(0)
	,_name("")
	,_serveradd("")
	,_port(0)
	,_dllPath(dllPath)
	,_my_exit(0)
	,_pState(0)
{
	try
	{
		hInst=LoadLibraryA(_dllPath.c_str());//��̬����Dll
		if (hInst==0)
		{
			std::stringstream strss;
			strss<<"LoadLibrary("<<dllPath<<") in "<<__FILE__<<"("<<__FUNCTION__<<")"
				<<" on line "<<__LINE__<<"\n";
			strss<<"# ERR:"<<GetLastError();
			WriteLog(strss.str());
			return;
		}
		_start=(StartFunc)::GetProcAddress(hInst,"Start");//��ȡDll�ĵ�������
		_stop=(StopFunc)::GetProcAddress(hInst,"Stop");//��ȡDll�ĵ�������
		_my_exit=(ExitFunc)::GetProcAddress(hInst,"Exit");
		_update=(UpdateFunc)::GetProcAddress(hInst,"UpdateClientsToSend");//��ȡDll�ĵ�������
		_getserver=(GetServerFunc)::GetProcAddress(hInst,"GetServer");
		_readconfig=(ReadConfigFunc)::GetProcAddress(hInst,"ReadConfig");
		_get_rcv_datasize=(GetRCVDataSizeFunc)::GetProcAddress(hInst,"GetRCVDataSize");
		_get_send_datasize=(GetSendDataSizeFunc)::GetProcAddress(hInst,"GetSendDataSize");
		if(_start && _stop && _my_exit
			&& _update && _getserver
			&& _readconfig && _get_rcv_datasize
			&& _get_send_datasize)
		{
			_readconfig();
			string strserver;
			_getserver(strserver);
			vector<string> fields;
			boost::split(fields,strserver,boost::is_any_of(":"));
			_seri_number=fields[0];
			_name=fields[1];
			_serveradd=fields[2];
			_port=atoi(fields[3].c_str());
		}
		else
		{
			std::stringstream strss;
			strss<<"_start="<<_start<<","
				<<"_stop="<<_stop<<","
				<<"_my_exit="<<_my_exit<<","
				<<"_update="<<_update<<","
				<<"_getserver="<<_getserver<<","
				<<"_readconfig="<<_readconfig<<","
				<<"_get_rcv_datasize="<<_get_rcv_datasize<<","
				<<"_get_send_datasize="<<_get_send_datasize;
		}
	}
	catch (std::exception& e)
	{
		std::stringstream strss;
		strss<<"# ERR: std::exception in "<<__FILE__<<"("<<__FUNCTION__<<")"
			<<" on line "<<__LINE__<<"\n";
		strss<<"# ERR:"<<e.what();
		WriteLog(strss.str());
	}
}

void CProInfo::InitiateState()
{

}
CProInfo::~CProInfo(void)
{
	Exit();
	if (hInst)
	{
		FreeLibrary(hInst);
	}
}

void CProInfo::Start()
{
	try
	{
		_start();
	}
	catch (std::exception& e)
	{
		std::stringstream strss;
		strss<<"# ERR: std::exception in "<<__FILE__<<"("<<__FUNCTION__<<")"
			<<" on line "<<__LINE__<<"\n";
		strss<<"# ERR:"<<e.what();
		WriteLog(strss.str());
	}
}
void CProInfo::Stop()
{
	try
	{
		_stop();
	}
	catch (std::exception& e)
	{
		std::stringstream strss;
		strss<<"# ERR: std::exception in "<<__FILE__<<"("<<__FUNCTION__<<")"
			<<" on line "<<__LINE__<<"\n";
		strss<<"# ERR:"<<e.what();
		WriteLog(strss.str());
	}
}
void CProInfo::Exit()
{
	try
	{
		_my_exit();
	}
	catch (std::exception& e)
	{
		std::stringstream strss;
		strss<<"# ERR: std::exception in "<<__FILE__<<"("<<__FUNCTION__<<")"
			<<" on line "<<__LINE__<<"\n";
		strss<<"# ERR:"<<e.what();
		WriteLog(strss.str());
	}
}
void CProInfo::Update()
{
	try
	{
		_update();
	}
	catch (std::exception& e)
	{
		std::stringstream strss;
		strss<<"# ERR: std::exception in "<<__FILE__<<"("<<__FUNCTION__<<")"
			<<" on line "<<__LINE__<<"\n";
		strss<<"# ERR:"<<e.what();
		WriteLog(strss.str());
	}
}
unsigned long long CProInfo::GetRCVDataSize()
{
	return _get_rcv_datasize();
}
unsigned long long CProInfo::GetSendDataSize()
{
	return _get_send_datasize();
}
