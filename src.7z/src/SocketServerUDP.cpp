#include "SocketServerUDP.h"
#include "globaldeclear.h"
#include <strstream>
#define BUFFER_SIZE_RECIVE 10240
#define MAXBUFFER_SIZE 500
#pragma comment(lib, "ws2_32.lib")

CSocketServerUDP::CSocketServerUDP(void)
{
	m_bStop=false;
	m_ullRecivedSize=0;
	recive_pool_prt = std::shared_ptr<boost::threadpool::pool>(new boost::threadpool::pool(1));
}

CSocketServerUDP::~CSocketServerUDP(void)
{
	Stop();
	Cleanup();
}

int CSocketServerUDP::Startup()
{
	int ret=0;
	WORD wVersionRequested;
	WSADATA wsaData;
	wVersionRequested = MAKEWORD( 2, 0 );	
	ret = WSAStartup( wVersionRequested, &wsaData );
	if ( ret != 0 ) 
	{
		stringstream strss;
		strss<<"Socket2.0��ʼ��ʧ�ܣ��˳�!������Ϣ��"<<GetErrorDetails(WSAGetLastError());
		WriteLog(strss.str());
		return ret;
	}	
	if ( LOBYTE( wsaData.wVersion ) != 2 ||	HIBYTE( wsaData.wVersion ) != 0 )
	{
		stringstream strss;
		strss<<"Socket2.0��ʼ��ʧ�ܣ��˳�!������Ϣ��"<<GetErrorDetails(WSAGetLastError());
		WriteLog(strss.str());
		return -1; 
	}
	return ret;
}
int CSocketServerUDP::Cleanup()
{
	int ret=-1;
	//while(ret!=0)
	{
		ret = WSACleanup();
	}
	return ret;
}
int CSocketServerUDP::Initiate()
{
	//2.�����׽���
	int ret=Startup();
	//UDP
	m_Socket = socket(AF_INET,SOCK_DGRAM,IPPROTO_UDP);//SOCK_STREAM
	if (m_Socket == INVALID_SOCKET ) 
	{
		stringstream strss;
		strss<<"Socket����ʧ��,������Ϣ!������Ϣ��"<<GetErrorDetails(WSAGetLastError());
		WriteLog(strss.str());
		return -1;
	}

	//3.bind�׽��֣��൱�ڸ������׽��ָ�ֵ
	sockaddr_in myaddr; 
	memset(&myaddr,0,sizeof(myaddr));
	myaddr.sin_family=AF_INET;

	myaddr.sin_addr.s_addr = htonl(INADDR_ANY);//inet_addr("127.0.0.1");
	myaddr.sin_port=htons(m_usServerPort);
	ret= ::bind(m_Socket,(sockaddr*)&myaddr,sizeof(myaddr));

	if (ret!=0)
	{
		stringstream strss;
		strss<<"�󶨶˿�ʧ��!������Ϣ��"<<GetErrorDetails(WSAGetLastError());
		WriteLog(strss.str());
		return ret;
	}

	int nNetTimeout=1000*60;//1�� 
	//����ʱ��
	setsockopt(m_Socket, SOL_SOCKET, SO_RCVTIMEO, (char*)&nNetTimeout, sizeof(nNetTimeout));
	setsockopt(m_Socket, SOL_SOCKET, SO_SNDTIMEO, (char*)&nNetTimeout, sizeof(nNetTimeout));
	return ret;
}
int CSocketServerUDP::ReciveMsg()
{
	int ret=0;
	int iResult = 0;
	WriteLog("��ʼ��������");
	char buffer[BUFFER_SIZE_RECIVE];
	memset(buffer,0,sizeof(buffer));
	while(true)
	{
		if (m_bStop)
		{
			break;
		}
		iResult = recv(m_Socket,buffer,sizeof(buffer),0);
		if (iResult <= 0)
		{
			if (!m_bStop)
			{
				stringstream strss;
				strss<<"��������ʧ��!������Ϣ��"<<GetErrorDetails(WSAGetLastError());
				WriteLog(strss.str());
			}
			else
			{
				WriteLog("�ֶ�ֹͣ����");
			}
		}
		else
		{
			m_ullRecivedSize+=iResult;
			PushToBuffer(buffer,iResult);
		}
	}
	if (iResult<=0)
	{
		ret=-1;
	}
	WriteLog("���շ���!");
	return ret;
}
int CSocketServerUDP::Close()
{
	int ret=closesocket(m_Socket);
	return ret;
}
int CSocketServerUDP::Start(void)
{
	int ret=0;
	if (m_usServerPort<1 || m_usServerPort>=65535)
	{
		WriteLog("����д��ȷ�Ľ��շ������˿ں�");
		return -1;
	}
	if ((ret = Initiate())!=0)
	{
		return ret;
	}
	//��ʼ��������
	m_bStop=false;
	recive_pool_prt->schedule(boost::bind(&CSocketServerUDP::ReciveMsg,this));
	return ret;
}
int CSocketServerUDP::Stop(void)
{
	m_bStop=true;
	Close();
	recive_pool_prt->clear();
	recive_pool_prt->wait();
	return 0;
}
void CSocketServerUDP::PushToBuffer(char* buffer,int len)
{
	boost::mutex::scoped_lock lock(mutexBuffer);
	if(m_vecBuffer.size()>=(MAXBUFFER_SIZE-1))
	{
		stringstream strss;
		strss<<"���ݻ���������δ������"<<m_vecBuffer.size()<<")";
		WriteLog(strss.str());
	}
	std::shared_ptr<CBufferObj> bufferobj = std::shared_ptr<CBufferObj>(new CBufferObj(buffer,len));
	m_vecBuffer.push_back(bufferobj);
}
void CSocketServerUDP::GetDataBuffer(vector<std::shared_ptr<CBufferObj>>& vecBuffer)
{
	boost::mutex::scoped_lock lock(mutexBuffer);
	if (m_vecBuffer.size()>0)
	{
		vecBuffer.insert(vecBuffer.end(),m_vecBuffer.begin(),m_vecBuffer.end());
		m_vecBuffer.clear();
	}
}