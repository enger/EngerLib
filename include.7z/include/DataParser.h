#pragma once
#include <config.h>
#include <BufferObj.h>

class CDataParser
{
public:
	CDataParser(void);
	~CDataParser(void);
};

