#pragma once
#include <config.h>
class ENGERLIB_EXP CState
{
public:
	CState(void);
	~CState(void);
public:
	unsigned long long ull_rev_size;
	unsigned long long ull_snd_size;
};

