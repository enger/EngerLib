#pragma once
#include <config.h>
#include <string>

extern "C" ENGERLIB_EXP void Start();
extern "C" ENGERLIB_EXP void Stop();
extern "C" ENGERLIB_EXP void Exit();
extern "C" ENGERLIB_EXP void UpdateClientsToSend();
extern "C" ENGERLIB_EXP void ReadConfig();
extern "C" ENGERLIB_EXP void GetServer(std::string& strRet);
extern "C" ENGERLIB_EXP unsigned long long GetRCVDataSize();
extern "C" ENGERLIB_EXP unsigned long long GetSendDataSize();