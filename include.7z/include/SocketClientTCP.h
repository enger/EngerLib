#ifndef SOKETCLIENT_HPP
#define SOKETCLIENT_HPP
#include "config.h"
#include <vector>
#include <winsock2.h>
#include <stdlib.h>
#include <string>
#include "BufferObj.h"
//#include "DataSourceState.h"
#include <boost/threadpool.hpp>
#include <boost/thread/mutex.hpp>

using namespace std;

#define BUFFER_SIZE_RECIVE 102400
class ENGERLIB_EXP CSocketClientTCP
{
public:
	enum SocketMode { ReciveOnly,SendOnly,Both};
private:
	SOCKET		m_Socket;
	sockaddr_in m_ServerAddr;
	string		m_strServerAddr;
	u_short		m_usServerPort;
	bool		m_bStop;
	vector<std::shared_ptr<CBufferObj>> m_vecRCVBuffer;
	vector<std::shared_ptr<CBufferObj>> m_vecSendBuffer;
	std::shared_ptr<boost::threadpool::pool> recive_pool_prt;
	std::shared_ptr<boost::threadpool::pool> send_pool_prt;
	boost::mutex mutexRCVBuffer;
	boost::mutex mutexSendBuffer;
	string		m_strName;
	unsigned long long ull_rcv_size;
	unsigned long long ull_snd_size;
public:
	CSocketClientTCP(void);
	~CSocketClientTCP(void);
private:
	int Startup();
	int Cleanup();
	int Close();
	int Initiate();
	int ReciveMsg();
	void PushToRCVBuffer(char* buffer,int len);
public:
	void SetAddrs(string serverAddr){m_strServerAddr=serverAddr;}
	void SetName(string name){m_strName=name;}
	void SetPorts(u_short serverport){m_usServerPort=serverport;}
	//������ʽ1=���գ�2=���ͣ�3=���պͷ���
	int Start(SocketMode mode);
	void Stop();
	int ConnectToServer();
	void GetRCVDataBuffer(vector<std::shared_ptr<CBufferObj>>& vecBuffer);
	void GetSendataBuffer(vector<std::shared_ptr<CBufferObj>>& vecBuffer);

	void SendData();
	void PushSendData(const std::shared_ptr<CBufferObj>& ptr_buffer);
	void PushSendData(const vector<std::shared_ptr<CBufferObj>>& vecbuffer);

	unsigned long long GetRCVSize(){return ull_rcv_size;}
	unsigned long long GetSendSize(){return ull_snd_size;}
};
#endif