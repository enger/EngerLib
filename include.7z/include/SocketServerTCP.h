#ifndef SOKETSERVER_HPP
#define SOKETSERVER_HPP

#include "config.h"
#include <winsock2.h>
#include <iostream>
#include <stdlib.h>
#include <vector>
#include <map>
#include <boost/shared_ptr.hpp>
#include <boost/threadpool.hpp>
#include <boost/thread/mutex.hpp>
#include <shlwapi.h>
#include <DataRouter.h>
using namespace std;

class  CSoketAndSend
{
public:
	CSoketAndSend()
	{
		socket_send_pool_prt = std::shared_ptr<boost::threadpool::pool>(new boost::threadpool::pool(1));
		IsValid=true;
	}
public:
	bool IsValid;
	SOCKET sockt;
	sockaddr_in addr;
	std::shared_ptr<boost::threadpool::pool> socket_send_pool_prt;
public:
	void SendMSG(shared_ptr<CBufferObj> buff)
	{
		if (buff==nullptr)
		{
			return;
		}
		socket_send_pool_prt->schedule(boost::bind(&CSoketAndSend::SendMSGThread,this,buff));
	}
	void SendMSGThread(shared_ptr<CBufferObj> buff)
	{
		int ret=send(sockt,&*(buff->ptr_buffer),buff->buff_length(),0);
		if (ret<=0)
		{
			IsValid=false;
			closesocket(sockt);
		}
	}
};


class ENGERLIB_EXP CSocketServerTCP
{
	typedef map<SOCKET,CSoketAndSend> CLIENTSOCKETS;
	typedef CLIENTSOCKETS::iterator CLIENTSOCKETS_ITE;
public:
	enum SocketMode { ReciveOnly,SendOnly};
private:
	unsigned long long m_ullSentSize;
	unsigned long long m_ullRecivedSize;
private:
	SOCKET	m_Socket;
	u_short	m_Port;
	std::shared_ptr<boost::threadpool::pool> socket_send_pool_prt;
	std::shared_ptr<boost::threadpool::pool> socket_recive_pool_prt;
	std::shared_ptr<boost::threadpool::pool> socket_listen_pool_prt;
	boost::mutex mutexCleints;
	CLIENTSOCKETS clientSockets;
	unsigned	maxConnet;
	bool m_bStop;
	bool	m_bTrans;
	SocketMode m_mode;
public:
	CSocketServerTCP(void);
	~CSocketServerTCP(void);
private:
	int	Initiate();
	int	ServerAccept();
	int	Close();
	//int SendMsg(char* msg, int len,SOCKET cleintSocket);
	//int SendMsgByThread(char* msg, int len);
	int Startup();
	int Cleanup();
	int ConnectSocketError(const SOCKET& cleintSocket);
	//int SendMsg(char* msg, int len);

	void Recive(const SOCKET& cleintSocket);
	void Send();
public:
	void SetServerPort(u_short p){m_Port=p;}
	//void TransData(bool bTrans){m_bTrans=bTrans;}
	int Start(SocketMode mode);
	int Stop();
	//void SendMsg(string strmsg);
	string GetClients();
	shared_ptr<engerlib::CDataRouter> m_prtDataRouter;
};
#endif