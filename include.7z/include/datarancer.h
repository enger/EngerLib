#pragma once
#include <config.h>
#include <SocketClientTCP.h>
#include <boost/threadpool.hpp>
#include <boost/thread/mutex.hpp>
#include <BufferObj.h>

class ENGERLIB_EXP CDataTrancer
{
public:
	CDataTrancer(void);
	~CDataTrancer(void);
public:
	//CSocketServerUDP	m_SocketSeverUDP;
	//CSocketServerTCP	m_SocketServer;
	CSocketClientTCP m_sktClientTCP;
private:
	string m_strServerAdd;
	u_short m_usPort;

	//u_short			m_usRecivePort;
	//u_short			m_usSendPort;
	//string			m_strCityFlag;
	bool			m_bStop;
	std::shared_ptr<boost::threadpool::pool> send_pool_prt;

public:
	//int	GetRecivePort(){return m_usRecivePort;}
	//int	GetSendPort(){return m_usSendPort;}
	void SetServerAdd(string strServer){m_strServerAdd=strServer;}
	void SetServerPort(u_short port){m_usPort=port;}
	int Start();
	void Stop();
	//int Initiate();
	void SendData(const std::shared_ptr<CBufferObj>& ptr_buffer);
};

