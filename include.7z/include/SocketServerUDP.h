#pragma once
#include <config.h>
#include <winsock2.h>
#include <iostream>
#include <stdlib.h>
#include <vector>
#include <map>
#include <string>
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <boost/threadpool.hpp>
#include <boost/thread/mutex.hpp>
#include "BufferObj.h"

using namespace std;

//class CSocketServer;
//#define BUFFER_SIZE  10240
//#define WRTITE_BUFFER_SIZE 1024*1024
class ENGERLIB_EXP CSocketServerUDP
{
public:
private:
	boost::mutex mutexBuffer;
	std::shared_ptr<boost::threadpool::pool> recive_pool_prt;
	SOCKET		m_Socket;
	u_short		m_usServerPort;
	ULONGLONG	m_ullRecivedSize;
	bool		m_bStop;
	vector<std::shared_ptr<CBufferObj>> m_vecBuffer;

public:
	CSocketServerUDP(void);
	~CSocketServerUDP(void);
private:
	int Startup();
	int Cleanup();
	int ReciveMsg();
	int Close();
	void PushToBuffer(char* buffer,int len);

public:
	void SetPort(u_short serverport){m_usServerPort=serverport;}
	int Start(void);
	int Stop(void);
	int Initiate();
	void GetDataBuffer(vector<std::shared_ptr<CBufferObj>>& vecBuffer);
	ULONGLONG GetReciveSize(){ return m_ullRecivedSize; }
};
