#pragma once
#include <config.h>
#include <map>
#include <memory>
#include <MyProInfo.h>

using namespace std;
class ENGERLIB_EXP CProManager
{
public:
	CProManager(void);
	~CProManager(void);
private:
	map<string,shared_ptr<CProInfo>> _mapPro;
public:
	void AddPro(const string& dllpath,bool startNow=true);
	void RemovePro(const string& name);
	void ClearPro();
	void Start();
	void Start(const string& dllname);
	void Stop();
	void Stop(const string& dllname);
	void Update();
	void Update(const string& dllname);
	 shared_ptr<CProInfo> GetProInfo(string dllname);
	 const map<string,shared_ptr<CProInfo>>& GetPros() const 
	 { 
		 return _mapPro;
	 }
};

